import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:startup_namer/screens/startup_names.dart';
import '../providers/auth.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  var isLoading = false;

  @override
  Widget build(BuildContext context) {
    Auth auth = Provider.of<Auth>(context);
    return Scaffold(
        appBar: AppBar(
          title: const Text('Login'),
        ),
        body: Builder(builder: (BuildContext context) {
          if (!isLoading) {
            return Form(
                child: Center(
                    child: Column(children: [
              const Padding(
                  padding: EdgeInsets.fromLTRB(70.0, 50.0, 70.0, 15.0),
                  child: Text(
                      "Welcome Aboard! please login if you wish to pick a startup name")),
              Padding(
                  padding: const EdgeInsets.fromLTRB(70.0, 10.0, 70.0, 20.0),
                  child: TextFormField(
                    controller: emailController,
                    decoration: const InputDecoration(
                      border: UnderlineInputBorder(),
                      labelText: 'Email',
                    ),
                  )),
              Padding(
                  padding: const EdgeInsets.fromLTRB(70.0, 20.0, 70.0, 40.0),
                  child: TextFormField(
                    obscureText: true,
                    enableSuggestions: false,
                    autocorrect: false,
                    controller: passwordController,
                    decoration: const InputDecoration(
                      border: UnderlineInputBorder(),
                      labelText: 'Password',
                    ),
                  )),
              SizedBox(
                  width: 150,
                  child: ElevatedButton(
                    style: ButtonStyle(
                        backgroundColor:
                            MaterialStateProperty.resolveWith<Color>(
                          (Set<MaterialState> states) {
                            return Colors.deepPurple;
                          },
                        ),
                        shape:
                            MaterialStateProperty.all<RoundedRectangleBorder>(
                                RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(18.0),
                        ))),
                    child: const Text('Login'),
                    onPressed: () async {
                      //LOGIN ACTION:
                      setState(() {
                        isLoading = true;
                      });
                      try {
                        bool res = await auth.signIn(
                            emailController.text, passwordController.text);
                        if (res) {
                          setState(() {
                            isLoading = false;
                          });
                          Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const StartupNames())).then((value) {
                            setState(() {
                              // refresh state
                            });
                          });
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text(
                                  'There was an error logging into the app'),
                            ),
                          );
                          setState(() {
                            isLoading = false;
                          });
                        }
                      } on Exception catch (e) {
                        setState(() {
                          isLoading = false;
                        });
                      }
                    },
                  ))
            ])));
          } else {
            return const SizedBox(
              height: 100,
              width: 100,
              child: Center(
                child: CircularProgressIndicator(),
              ),
            );
          }
        }));
  }
}

