import 'package:flutter/material.dart';
import 'package:english_words/english_words.dart';
import 'package:provider/provider.dart';
import 'package:startup_namer/providers/auth.dart';
import 'package:startup_namer/providers/favorites.dart';

class StartupNames extends StatefulWidget {
  const StartupNames({Key? key}) : super(key: key);

  @override
  _StartupNamesState createState() => _StartupNamesState();
}

class _StartupNamesState extends State<StartupNames> {
  final _biggerFont = const TextStyle(fontSize: 18); // NEW
  final _suggestions = generateWordPairs().take(10).toList(); // NEW

  // final _biggerFont = const TextStyle(fontSize: 18); // NEW
  @override
  Widget build(BuildContext context) {
    return Consumer<Auth>(builder: (context, auth, _) {
      return Scaffold(
        // Add from here...
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: const Text('Startup Name Generator'),
          actions: [
            IconButton(
              icon: const Icon(Icons.list),
              onPressed: () {
                Navigator.pushNamed(context, '/favorites');
              },
              tooltip: 'Saved Suggestions',
            ),
            IconButton(
              icon: auth.status == Status.Authenticated
                  ? const Icon(Icons.exit_to_app)
                  : const Icon(Icons.login),
              onPressed: () async {
                // Navigate to the second screen using a named route.
                if (auth.status == Status.Authenticated) {
                  await auth.signOut();
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text("Successfully logged out"),
                    ),
                  );
                } else {
                  Navigator.pushNamed(context, '/login');
                }
              },
              tooltip: 'Login',
            ),
          ],
        ),
        body: _buildSuggestions(),
      ); // ... to here.
    });
  }

  Widget _buildSuggestions() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemBuilder: (context, i) {
        if (i.isOdd) {
          return const Divider();
        }
        final index = i ~/ 2;
        if (index >= _suggestions.length) {
          _suggestions.addAll(generateWordPairs().take(10));
        }
        return _buildRow(_suggestions[index]);
      },
    );
  }

  Widget _buildRow(WordPair pair) {
    // var favorites = Provider.of<Favorites>(context);
    // var _saved =favorites.favorites;
    return Consumer<Favorites>(builder: (context, _favorites, _) {
      final favorites = _favorites.favorites;
      bool inFavorites = favorites.contains(pair);
      return ListTile(
        title: Text(
          pair.asPascalCase,
          style: _biggerFont,
        ),
        trailing: Icon(
          inFavorites ? Icons.star : Icons.star_border,
          color: inFavorites ? Colors.deepPurple : null,
          semanticLabel: inFavorites ? 'Remove from saved' : 'Save',
        ),
        onTap: () {
          _favorites.toggleFavorite(pair);
        }, // ... to here.
      );
    });
  }
}
